import { mkdir, writeFile } from 'node:fs/promises';

await mkdir('dist', { recursive: true });

const info = {
  message: 'Hello from GitHub Actions!',
  builtAt: new Date().toISOString(),
  runner: process.env.RUNNER_OS || process.platform,
  node: process.version
};

await writeFile('dist/hello.txt', `${info.message}\n`, 'utf8');
await writeFile('dist/build-info.json', `${JSON.stringify(info, null, 2)}\n`, 'utf8');

console.log('build complete:', info);
