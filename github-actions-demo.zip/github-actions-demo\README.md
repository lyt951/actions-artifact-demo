# GitHub Actions 构建 + Artifact 下载演示

这是一个**无害的演示项目**，用来完整走一遍：

```text
创建/复制仓库
  → Actions 启用工作流
  → 手动 Run workflow
  → 云端构建
  → 下载 artifact ZIP
  → 解压得到产物
```

它不会破解软件、不会下载 EXE，只生成两个文本文件：

- `hello.txt`
- `build-info.json`

---

## 一、创建演示仓库

1. 登录 GitHub。
2. 右上角 **+** → **New repository**。
3. 填写：
   - Repository name：`actions-artifact-demo`
   - Visibility：**Public**
   - 勾选 **Add a README file**
4. 点 **Create repository**。

---

## 二、上传构建脚本

1. 进入新仓库。
2. 点 **Add file** → **Upload files**。
3. 上传这两个文件：

```text
package.json
build.mjs
```

4. 点 **Commit changes**。

---

## 三、创建 workflow

1. 点 **Add file** → **Create new file**。
2. 文件名填：

```text
.github/workflows/build.yml
```

> 输入 `/` 会自动创建目录，不要改成别的路径。

3. 把下面内容完整粘贴进去：

```yaml
name: Build demo artifact

on:
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up Node
        uses: actions/setup-node@v4
        with:
          node-version: 22

      - name: Build files
        run: node build.mjs

      - name: Upload artifact
        uses: actions/upload-artifact@v4
        with:
          name: demo-artifact
          path: dist/
          if-no-files-found: error
```

4. 点 **Commit changes**，提交到 `main` 分支。

---

## 四、运行 workflow

1. 打开仓库顶部的 **Actions** 标签。
2. 左侧选择 **Build demo artifact**。
3. 右侧点 **Run workflow**。
4. Branch 选 `main`。
5. 再点绿色的 **Run workflow**。

---

## 五、下载 artifact

1. 刷新 Actions 页面。
2. 点刚出现的那条运行记录。
3. 等 Job 变成绿色对勾。
4. 拉到页面底部，找到 **Artifacts**。
5. 点 **demo-artifact** 下载 ZIP。
6. 解压后应该看到：

```text
hello.txt
build-info.json
```

`build-info.json` 里能看到构建时间、Runner 系统和 Node 版本。

---

## 六、每一步在干嘛

| 步骤 | 作用 |
|---|---|
| `workflow_dispatch` | 让 Actions 页面出现「Run workflow」按钮，可以手动触发 |
| `actions/checkout@v4` | 把仓库代码拉到云端 Runner |
| `actions/setup-node@v4` | 安装指定 Node 版本 |
| `node build.mjs` | 执行构建脚本，生成 `dist/` |
| `actions/upload-artifact@v4` | 把 `dist/` 打包成 artifact，供下载 |

---

## 关于 Fork

上面是「新建仓库」的流程。Fork 只是把别人的仓库复制到你账号下，后续完全一样：

1. 打开目标仓库，点右上角 **Fork**。
2. 进入你自己账号下的副本。
3. 如果 Actions 提示工作流未启用，点 **I understand my workflows, go ahead and enable them**。
4. 后续同样：Actions → 选 workflow → Run workflow → 下载 artifact。

> 不要对来路不明的仓库点 Run workflow。workflow 里的代码会在云端执行，并能读取该仓库的 token；只运行你信任的 workflow。

---

## 本地验证构建脚本（可选）

在项目目录执行：

```powershell
node build.mjs
```

会生成 `dist/hello.txt` 和 `dist/build-info.json`，效果与云端一致。
